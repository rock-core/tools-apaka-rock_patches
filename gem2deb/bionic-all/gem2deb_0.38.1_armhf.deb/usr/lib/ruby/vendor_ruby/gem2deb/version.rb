module Gem2Deb
  VERSION = '0.38.1'
end
