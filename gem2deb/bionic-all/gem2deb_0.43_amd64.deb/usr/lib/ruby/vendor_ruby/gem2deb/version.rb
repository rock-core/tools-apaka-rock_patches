module Gem2Deb
  VERSION = '0.43'
end
