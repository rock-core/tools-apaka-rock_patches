module Gem2Deb
  VERSION = '0.33.1'
end
