module Gem2Deb
  VERSION = '0.37'
end
