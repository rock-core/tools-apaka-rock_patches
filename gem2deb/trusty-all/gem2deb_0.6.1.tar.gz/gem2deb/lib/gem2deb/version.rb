module Gem2Deb
  VERSION = '0.6.1'
end
