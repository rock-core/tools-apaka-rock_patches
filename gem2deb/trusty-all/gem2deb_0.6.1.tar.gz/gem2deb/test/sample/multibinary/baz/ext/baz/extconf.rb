require 'mkmf'
create_makefile('baz')
