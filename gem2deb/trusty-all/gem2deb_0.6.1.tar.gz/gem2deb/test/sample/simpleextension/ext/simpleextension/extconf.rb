require 'mkmf'
create_makefile('simpleextension')
