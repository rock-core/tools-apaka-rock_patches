require 'simpleextension_with_name_clash.so'

module SimpleExtensionWithNameClash
  ANSWER_42 = 42
end
