require 'mkmf'
create_makefile('simplemixed')
