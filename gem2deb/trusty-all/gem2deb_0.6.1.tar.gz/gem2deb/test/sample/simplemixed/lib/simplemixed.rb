require 'simplemixed.so'
