#include "ruby.h"

void Init_simpleextension_in_root() {
  rb_define_module("SimpleExtensionInRoot");
}
