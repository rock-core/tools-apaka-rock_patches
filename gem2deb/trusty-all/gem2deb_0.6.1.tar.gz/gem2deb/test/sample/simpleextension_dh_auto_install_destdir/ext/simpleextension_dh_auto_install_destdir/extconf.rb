require 'mkmf'
create_makefile('simpleextension_dh_auto_install_destdir')
