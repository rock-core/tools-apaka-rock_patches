require 'test/unit'

class TestTest < Test::Unit::TestCase
  def test_test
    assert false
  end
end
