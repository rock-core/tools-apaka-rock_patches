exec('debian/ruby-simpleprogram-no-shebang/usr/bin/simpleprogram')
