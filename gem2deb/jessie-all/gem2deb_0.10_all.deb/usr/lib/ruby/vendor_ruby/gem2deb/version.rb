module Gem2Deb
  VERSION = '0.10'
end
