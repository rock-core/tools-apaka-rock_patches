module Gem2Deb
  VERSION = '0.31'
end
